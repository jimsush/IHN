var people_mtl = getRawText(function(){/*

# 3ds Max Wavefront OBJ Exporter v0.97b - (c)2007 guruware
# File Created: 06.08.2015 14:44:59

newmtl CMan0001
	Ns 53.8082
	Ni 1.0000
	d 1.0000
	Tr 0.0000
	Tf 1.0000 1.0000 1.0000 
	illum 2
	Ka 0.2353 0.2353 0.2353
	Kd 0.7843 0.7843 0.7843
	Ks 0.0000 0.0000 0.0000
	Ke 0.0000 0.0000 0.0000
	map_Ka people.png
	map_Kd people.png

*/});