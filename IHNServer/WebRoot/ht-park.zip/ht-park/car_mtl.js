var car_mtl = getRawText(function(){/*

# Blender MTL File: 'untitled7.blend'
# Material Count: 3
newmtl Material.001_WheelD.png
	Ns 96.078431
	Ka 0.000000 0.000000 0.000000
	Kd 0.640000 0.640000 0.640000
	Ks 0.500000 0.500000 0.500000
	Ni 1.000000
	d 1.000000
	illum 2
	map_Kd WheelD.png
	map_d WheelD.png


newmtl Material.002_glass.png
	Ns 96.078431
	Ka 0.000000 0.000000 0.000000
	Kd 0.640000 0.640000 0.640000
	Ks 0.500000 0.500000 0.500000
	Ni 1.000000
	d 0.200000
	illum 2


newmtl 001
	Ns 96.078431
	Ka 0.000000 0.000000 0.000000
	Kd 0.640000 0.640000 0.640000
	Ks 0.500000 0.500000 0.500000
	Ni 1.000000
	d 1.000000
	illum 2


*/});